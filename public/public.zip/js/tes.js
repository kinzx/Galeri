// Gunakan library Masonry
var grid = new Masonry(".grid", {
  // Opsi konfigurasi
});

// Tambahkan item baru ke grid
grid.addItems(item);

// Filter item di grid
grid.filter(".category-1");
